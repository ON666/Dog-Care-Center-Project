-- CREATE TABLE admin_users
CREATE TABLE admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL
);

-- INSERT INTO admin_users
INSERT INTO admin_users (username, password) VALUES ('alina', 'alina123');





-- CREATE TABLE newsletter_subscribers
CREATE TABLE newsletter_subscribers (
    subscriber_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    email VARCHAR(255) NOT NULL UNIQUE,
    subscription_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES User(UserID)
);

-- CREATE TABLE dog_details
CREATE TABLE dog_details (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    breed VARCHAR(255) NOT NULL,
    time VARCHAR(50) NOT NULL,
    date DATE NOT NULL,
    number VARCHAR(20) NOT NULL
);


