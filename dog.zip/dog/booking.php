<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['username'])) {
    header("Location: index.html"); // Redirect to login page if not logged in
    exit();
}

// Database connection (replace with actual database connection)
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "your_database";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch booking details from the database (replace with actual query)
$sql = "SELECT * FROM bookings";
$result = $conn->query($sql);

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
        margin: 0;
        padding: 0;
    }

    .admin-container {
        max-width: 800px;
        margin: 50px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h2 {
        text-align: center;
        margin-bottom: 20px;
    }

    .booking-details table {
        width: 100%;
        border-collapse: collapse;
    }

    .booking-details th, .booking-details td {
        padding: 8px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    .booking-details th {
        background-color: #f2f2f2;
    }

    .booking-details td {
        background-color: #fff;
    }

    a {
        display: block;
        text-align: center;
        margin-top: 20px;
        color: #007bff;
        text-decoration: none;
    }

    a:hover {
        text-decoration: underline;
    }
</style>
</head>
<body>
<div class="admin-container">
    <h2>Booking Details</h2>
    <div class="booking-details">
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Date</th>
                <th>Email</th>
                <th>Breed</th>
                <th>Time</th>
                <th>Number</th>
            </tr>
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>".$row["id"]."</td>";
                    echo "<td>".$row["name"]."</td>";
                    echo "<td>".$row["date"]."</td>";
                    echo "<td>".$row["email"]."</td>";
                    echo "<td>".$row["breed"]."</td>";
                    echo "<td>".$row["time"]."</td>";
                    echo "<td>".$row["number"]."</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='3'>No bookings found</td></tr>";
            }
            ?>
        </table>
    </div>
    <a href="index.html">Logout</a>
</div>
</body>
</html>
