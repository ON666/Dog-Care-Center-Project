<?php

$servername = "localhost"; // Change this to your MySQL server address
$username = "username"; // Change this to your MySQL username
$password = "password"; // Change this to your MySQL password
$database = "database"; // Change this to your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate input data
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $subscriberID = uniqid(); // Generate a unique identifier for the subscriber

    // Insert email into database
    $sql = "INSERT INTO newsletter_subscribers (subscriber_id, email) VALUES ('$subscriberID', '$email')";

    if ($conn->query($sql) === TRUE) {
        echo "Thank you for subscribing to our newsletter!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close connection
$conn->close();
?>
