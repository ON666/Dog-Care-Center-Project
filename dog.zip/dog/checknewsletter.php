<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Newsletter Subscribers</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h2>Newsletter Subscribers</h2>
    <table>
        <tr>
            <th>Subscriber ID</th>
            <th>User ID</th>
            <th>Email</th>
            <th>Subscription Date</th>
        </tr>
        <?php
        // Database connection parameters
        $host = 'your_host';
        $username = 'your_username';
        $password = 'your_password';
        $database = 'your_database';

        // Create connection
        $conn = new mysqli($host, $username, $password, $database);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Fetch data from the 'newsletter_subscribers' table
        $sql = "SELECT * FROM newsletter_subscribers";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Output data of each row
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["subscriber_id"] . "</td>";
                echo "<td>" . $row["user_id"] . "</td>";
                echo "<td>" . $row["email"] . "</td>";
                echo "<td>" . $row["subscription_date"] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No data found</td></tr>";
        }

        // Close connection
        $conn->close();
        ?>
    </table>
    <button onclick="window.location.href='index.html'">Logout</button>
</body>
</html>
