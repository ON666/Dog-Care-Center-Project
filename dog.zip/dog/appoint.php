<?php

$servername = "localhost"; // Change this to your MySQL server address
$username = "username"; // Change this to your MySQL username
$password = "password"; // Change this to your MySQL password
$database = "database"; // Change this to your MySQL database name


$conn = new mysqli($servername, $username, $password, $database);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $breed = mysqli_real_escape_string($conn, $_POST['breed']);
    $time = mysqli_real_escape_string($conn, $_POST['time']);
    $date = mysqli_real_escape_string($conn, $_POST['date']);
    $number = mysqli_real_escape_string($conn, $_POST['number']);

   
    $sql = "INSERT INTO dog (name, email, breed, time, date, number) 
            VALUES ('$name', '$email', '$breed', '$time', '$date', '$number')";

f ($conn->query($sql) === TRUE) {
    // Appointment booked successfully
    echo "<script>alert('Appointment booked! You will receive a notification soon.');</script>";
    // Redirect back to the index page after 3 seconds
    echo "<script>window.setTimeout(function(){ window.location.href = 'index.html'; }, 3000);</script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}

// Close connection
$conn->close();
?>
