<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vaccination Details</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h2>Vaccination Details</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Email</th>
            <th>Name</th>
            <th>Date</th>
            <th>Dose</th>
        </tr>
        <?php
        // MySQL database connection parameters
        $host = 'your_host';
        $username = 'your_username';
        $password = 'your_password';
        $database = 'your_database';

        // Create connection
        $conn = new mysqli($host, $username, $password, $database);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Fetch data from the 'vaccination' table
        $sql = "SELECT * FROM vaccination";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Output data of each row
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["id"] . "</td>";
                echo "<td>" . $row["Email"] . "</td>";
                echo "<td>" . $row["name"] . "</td>";
                echo "<td>" . $row["date"] . "</td>";
                echo "<td>" . $row["dose"] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>No data found</td></tr>";
        }

        // Close connection
        $conn->close();
        ?>
    </table>
    <button onclick="window.location.href='index.html'">Logout</button>
</body>
</html>
