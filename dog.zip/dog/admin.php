<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            margin-top: 0;
        }

        form {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="number"],
        input[type="email"],
        input[type="text"],
        input[type="date"],
        input[type="time"] {
            width: 100%;
            margin-bottom: 10px;
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        button {
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .newsletter-button {
            background-color: #28a745;
        }

        .newsletter-button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Update Vaccination Details</h2>
        <form method="post">
            <label for="idX">ID:</label>
            <input type="number" id="idX" name="idX" required>
            <label for="emailX">Email:</label>
            <input type="email" id="emailX" name="emailX" required>
            <label for="nameX">Name:</label>
            <input type="text" id="nameX" name="nameX" required>
            <label for="dateX">Date:</label>
            <input type="date" id="dateX" name="dateX" required>
            <label for="doseX">Dose:</label>
            <input type="number" id="doseX" name="doseX" required>
            <button type="submit" name="submitX">Update</button>
        </form>

        <form action="checknewsletter.php" method="post">
            <!-- Add your fields for Table Y here -->

            <button class="newsletter-button" type="submit" name="checkNewsletter">Check Newsletter</button>
        </form>
        <button class="newsletter-button" onclick="window.location.href='booking.php'">Check Bookings</button>
        <button class="newsletter-button" onclick="window.location.href='index.html'">Logout</button>
    </div>
</body>
</html>
