<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fetch Vaccination Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        .container {
            width: 400px;
            margin: 100px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        input[type="text"], button {
            width: 100%;
            margin-bottom: 10px;
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        h2 {
            margin-top: 0;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            margin-bottom: 10px;
            padding: 10px;
            background-color: #f9f9f9;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        li:last-child {
            margin-bottom: 0;
        }
        p {
            margin-top: 10px;
            color: #ff0000;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Fetch Vaccination Details</h2>
        <form method="post">
            <label for="email">Enter Email:</label><br>
            <input type="text" id="email" name="email" required><br>
            <button type="submit">Fetch Details</button>
        </form>
        <?php
        // Check if form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $email = $_POST["email"];

            // MySQL database connection parameters
            $host = 'your_host';
            $username = 'your_username';
            $password = 'your_password';
            $database = 'your_database';

            // Create connection
            $conn = new mysqli($host, $username, $password, $database);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetch data from the 'vaccination' table based on email
            $sql = "SELECT * FROM vaccination WHERE Email = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                // Output data of each row
                echo "<h3>Vaccination Details for Email: $email</h3>";
                echo "<ul>";
                while($row = $result->fetch_assoc()) {
                    echo "<li><strong>Name:</strong> " . $row["Name"] . "<br><strong>Date:</strong> " . $row["Date"] . "<br><strong>Dose:</strong> " . $row["Dose"] . "</li>";
                }
                echo "</ul>";
            } else {
                echo "<p>No vaccination details found for email: $email</p>";
            }

            // Close prepared statement and connection
            $stmt->close();
            $conn->close();
        }
        ?>
    </div>
</body>
</html>
